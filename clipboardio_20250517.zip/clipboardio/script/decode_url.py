import urllib.parse
import pyperclip

clip = pyperclip.paste()
url = urllib.parse.unquote(clip)

print(url, end="")
