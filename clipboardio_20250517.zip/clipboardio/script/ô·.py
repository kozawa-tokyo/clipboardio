import datetime

now = datetime.datetime.now()
d = now.strftime('%d')

print(d, end="")
