import urllib.parse
import pyperclip

clip = pyperclip.paste()

print(clip, end="")
