import datetime

day = datetime.datetime.now()
dow = day.weekday()
day_name = '月火水木金土日'

print(day_name[dow], end="")
