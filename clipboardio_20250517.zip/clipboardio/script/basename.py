import os
import pyperclip

try:
    clipboard_content = pyperclip.paste()
    if clipboard_content:
        lines = clipboard_content.splitlines()
        filenames = []
        for line in lines:
            filename = os.path.basename(line.strip())
            if filename:
                filenames.append(filename)
        if filenames:
            filenames_string = os.linesep.join(filenames)
            print(filenames_string, end="")

except pyperclip.PyperclipException as e:
    print(f"クリップボードへのアクセスに失敗しました: {e}", end="")
except Exception as e:
    print(f"予期せぬエラーが発生しました: {e}", end="")
