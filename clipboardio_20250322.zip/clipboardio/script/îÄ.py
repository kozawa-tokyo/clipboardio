import datetime

now = datetime.datetime.now()
m = now.strftime('%m')

print(m, end="")
