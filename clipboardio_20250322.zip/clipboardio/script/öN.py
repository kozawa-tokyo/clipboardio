import datetime

now = datetime.datetime.now()
Y = now.strftime('%Y')

print(Y, end="")
