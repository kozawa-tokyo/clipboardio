import urllib.parse
import pyperclip

clip = pyperclip.paste()
length = len(clip)
fmtLength = format(length, ',')

print(fmtLength, end="")
