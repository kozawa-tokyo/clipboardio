import datetime

now = datetime.datetime.now()
M = now.strftime('%M')

print(M, end="")
