import datetime

now = datetime.datetime.now()
H = now.strftime('%H')

print(H, end="")
