import datetime

now = datetime.datetime.now()
S = now.strftime('%S')

print(S, end="")
